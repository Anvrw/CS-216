/*
 * Course: CS216-00x
 * Author: Andrew Tackett
 * Project: Project 2
 * Purpose: repeatedly ask the user to type prefix to match (cHANGE)
 *          then generate at maximum THREE matched terms 
 *          and display the matched terms in descending order by weight.
 ***** PLEASE DO NOT CHANGE THIS FILE *****
 */

#include <iostream>
#include <fstream>
#include <string>
#include <sstream>
#include <ctime>
#include "term.h"
#include "SortingList.h"
#include "autocomplete.h"

using namespace std;

int main(int argc, char** argv) {
    const int ARGUMENTS = 3;
    
    // check the command line argument, an input file name is needed
    if (argc != ARGUMENTS)
    {
        cout << "Usage: " << argv[0] << " <filename> number" << endl;
        return 1;
    }    
    
    // check if the input file can be opened successfully
    ifstream infile;
    infile.open(argv[1]);
    if (!infile.good())
    {
        cout << "Cannot open the file named " << argv[1] << endl;
        return 2;
    }  
    
    // read in the terms from the input file
    // line by line and store into Autocomplete object
    string tempString = argv[2];
    stringstream str;
    str << tempString; int numItemsListed; str >> numItemsListed;
    Autocomplete autocomplete;
    long weight;
    string query;
    
    while (!infile.eof())
    {
        infile >> weight >> ws;
        getline(infile, query);
        if (query != "")
        {    
            Term newterm(query, weight);
            autocomplete.insert(newterm);
        }    
    } 
    
    autocomplete.sort();
    string input;
    string prefix;
    cout << "Please input the search query (type \"exit\" to quit): " << endl;
    getline(cin, input);
    prefix = input;
    while (prefix != "exit")
    {
        // measure the time spent for searching one prefix-matched term
        SortingList<Term> matchedTerms = autocomplete.allMatches(prefix);
        
        if (matchedTerms.size() == 0)
        {    
           cout << "No matched query!" << endl;
        }
        else
        {
            if (matchedTerms.size() < numItemsListed){
                for (int i = 0; i < matchedTerms.size(); i++){
                    cout << matchedTerms[i];
                }
            }
            else {

                for (int i = 0; i < numItemsListed; i++){
                    cout << matchedTerms[i];
                }

            }
        }

        cout << "Please input the search query (type \"exit\" to quit): " << endl;
        getline(cin, input);
        prefix = input;
    }    
    return 0;
}

